# PHASE 1 PROMPT — Foundation + Content Pipeline

You are the build agent for **Bazaar**, a live trading-simulation platform for E-Summit at PEC (400–500 teams, 11 sessions in 2 rounds, run by an admin). You work **only from the master folder** `master/`. You have no other source of truth.

## 0. Before you write any code
1. Read, in this order, completely: `master/00_INDEX_AND_RULES.md`, `01`, `02`, `03`, `04`, `05`, `06`, `07`, `08`, `audit/AUDIT_RULES.md`, `audit/AUDIT_LOG_TEMPLATE.md`, `simulation.md`.
2. Re-state to yourself the hard rules in `00` §3. They apply for the whole project. If anything in the master folder is ambiguous or contradictory, **stop and add an entry to `OPEN_QUESTIONS.md`** instead of guessing.
3. You are doing **Phase P1 only**. Do not start Phase 2. Do not write price-generation logic, trading logic or UI beyond what is listed here.

## 1. Scope (what to build)

### 1.1 Repository & environment
- Create the layout in `00` §8: `master/` (copy of the master docs, `chmod 444`, with `master/MANIFEST.sha256` from `sha256sum`), `data/`, `backend/`, `frontend/`, `engine/`, `tools/`, `tests/`, `audit/`, `OPEN_QUESTIONS.md`, `CHANGE_REQUESTS.md`.
- Docker Compose with: PostgreSQL 16, backend (Python 3.12, FastAPI, asyncpg, SQLAlchemy 2, Alembic), frontend (Next.js, TypeScript) as a placeholder page. One command (`docker compose up`) brings everything up from a clean clone.
- Alembic **baseline migration** creating every table in `07` §5 (columns as listed; money as BIGINT paise; `orders.client_key` UNIQUE; `news_items.truth` stored but never exposed). Provide `alembic upgrade head` and `downgrade base`.
- Backend: `GET /health` returning `{status, db, time}`; structured JSON logging; config via env.
- Tooling: ruff + mypy (backend), eslint + tsc (frontend), pytest. A `Makefile` or `tools/ci.sh` running lint + type + tests.

### 1.2 Content pipeline (master docs → data)
Write `tools/ingest.py` that **parses the markdown tables inside the master files** (not hand-copied) and writes:
- `data/instruments.json` — 15 instruments (ticker, name, sector, personality, unlock_g, open price at unlock, P/E at unlock, blurb, shares_outstanding from `03` §9).
- `data/session_targets.json` — the full return matrix of `03` §2 (including MERX50 computed per `03` §8).
- `data/fundamentals.json` — EPS bars (4 pre-history + sessions), company P/E at open, industry P/E, Gross NPA, per `03` §4–§7.
- `data/events.json` — every event in `02` §2 (id, g, t_e, shape, net effects per ticker, peak).
- `data/news_ledger.json` — every signal in `02` §4 (id, source, text, event_id, ticker, implied dir, truth (bool), round, release rule: R1 `t_E` / R2 `min_research` = 2 for IN else 0, foreshadow release time if given) and the 4 informational items.
- Load all of the above into the database (seed script).
- `tools/validate_content.py` that **independently recomputes** and checks (see gates G1.7–G1.11).

### 1.3 Audit tooling (this is part of the deliverable)
- `audit/gates.json`: machine-readable list of **all Phase P1 gates** copied verbatim from `08` (fields: `gate_id`, `requirement`, `op` (`>=`,`<=`,`==`,`all_pass`), `threshold`, `unit`, `star` (bool)).
- Evidence JSON format (one file per gate at `audit/evidence/P1/<gate_id>.json`):
  ```json
  {"gate_id":"G1.4","measured":38.2,"unit":"ms","command":"...","commit":"<full sha>","utc":"2026-10-04T10:21:00Z",
   "env":{"os":"...","cpu":"...","ram_gb":0,"python":"...","node":"...","postgres":"..."},
   "raw_output_file":"audit/evidence/P1/G1.4.raw.txt","raw_sha256":"..."}
  ```
- `tools/audit_verify.py <phase>`: for each gate in `audit/gates.json` for that phase, load its evidence JSON, **recompute PASS/FAIL arithmetically** from `measured` vs `threshold`/`op`, verify `raw_sha256` matches the raw file, verify the commit exists in git, print a table, and exit **non-zero if any gate is missing, FAIL, or has a hash mismatch**.

## 2. Gates (all HARD; copy verbatim into the audit log; thresholds from `08`)

| Gate | Requirement | Threshold |
|---|---|---|
| G1.1 ★ | Clean-clone build + `docker compose up` | succeeds, 0 errors |
| G1.2 ★ | Alembic upgrade → downgrade → upgrade | all pass, schema diff 0 |
| G1.3 ★ | Unit tests | 100% pass; ≥ 20 tests |
| G1.4 | `/health` load: 1000 requests, 50 concurrent | p95 ≤ 50 ms, 0 errors |
| G1.5 ★ | `sha256sum -c master/MANIFEST.sha256` | all OK |
| G1.6 | Lint/type (ruff, mypy, eslint, tsc) | 0 errors |
| G1.7 ★ | Instruments: count and live-per-session vs `03` §1 and 01 §3 | 15 instruments; live counts 7,8,9,10,11,12,12,13,14,15,15 |
| G1.8 ★ | Session-target matrix vs `03` §2 (every cell) | 0 diffs |
| G1.9 ★ | Recompute: closes from returns, P/E = open ÷ EPS, industry P/E (0.8/0.2 rule), index weights (raw ÷ live sum), EPS pre-history ÷1.015^k and overrides; session EPS values are frozen inputs | max abs diff ≤ 0.01 |
| G1.10 ★ | News ledger: 64 signals + 4 info; per-source counts 25/14/10/15; truth recomputed from events | all equal; accuracies within ±6 pp of 55/75/90/35 |
| G1.11 ★ | Every signal → existing event & ticker live that session; **0 Insider items in Round 1**; every Insider item has `min_research = 2` | 0 violations |
| G1.12 | Truth flag in any API/WS payload (grep + live probe) | 0 occurrences |
| G1.13 | `audit_verify.py` self-test: a fabricated failing evidence JSON exits non-zero; a passing one exits 0 | both behave |

## 3. Rules while working
- **Do not edit anything under `master/`.** Do not "fix" a number you think is wrong — log it in `OPEN_QUESTIONS.md`.
- Every threshold in `08` stays exactly as written. If a gate cannot be met, report FAIL with the measured number.
- Money is integer paise; truth flags are never serialised outside the DB.
- Measure with real commands (`pytest`, `alembic`, `ab`/`wrk`/`hey` or a Python load script for `/health`, etc.). Save raw outputs. **No hand-typed results.**
- Write unit tests for the parser, each validator, the audit verifier, and the health endpoint. Tests must include at least one test that deliberately fails the validators on corrupted data to prove they can fail.

## 4. Procedure
1. Scaffold → migrations → health → tooling → ingest → validators → audit tooling → tests.
2. Run every gate command; write evidence JSON + raw files into `audit/evidence/P1/`.
3. Run `python tools/audit_verify.py P1` — it must exit 0.
4. Append a completed **Phase P1 section** to `audit/AUDIT_LOG.md` using `audit/AUDIT_LOG_TEMPLATE.md` (every field filled, real numbers, evidence hashes, defect register, regression table (none yet), environment).
5. Tag git `phase-P1-pass` only if every gate is PASS.

## 5. Final output to the organizer
Reply with: (a) a table of the 13 gates with measured value vs threshold and PASS/FAIL, (b) the path of the audit section, (c) open questions raised, (d) the exact commands to re-run any 3 gates independently. **Then stop. Do not begin Phase 2 until the organizer signs the Phase P1 audit block.**

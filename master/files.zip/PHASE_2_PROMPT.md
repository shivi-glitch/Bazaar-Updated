# PHASE 2 PROMPT — Round 1 Price Generator & Solvability

**Entry condition:** the Phase P1 audit block in `audit/AUDIT_LOG.md` is signed by the organizer and tag `phase-P1-pass` exists. If not, stop and say so.

You are the build agent for Bazaar. Read again, fully: `master/00`, `master/03`, `master/04`, `master/02` (§2 events and §4 R1 releases), `audit/AUDIT_RULES.md`. The hard rules in `00` §3 apply (determinism, paise, no invented numbers, no editing `master/`).

## 1. Goal
Build the **offline Round 1 price generator** exactly as specified in `04`, freeze its output, and prove with numbers that every acceptance test T1–T13 passes. Round 1 prices are a pure function of `(master_seed, session, ticker)`; the live engine (Phase 5) will only read these arrays.

## 2. Deliverables
- `tools/gen_r1.py` — generator (CLI: `--out data/ --verify`).
- `data/prices_r1.parquet` (columns: g, ticker, n, price_paise, volume; n = 0..600 per session per live instrument), `data/prehistory.parquet` (240 ticks per instrument ending at the open), `data/params.json` (`master_seed`, accepted seed offset `k` per session, personality table, regime table), `data/r1_arrays.sha256`.
- `tools/verify_r1.py` — implements tests T1–T13 and writes one JSON per gate under `audit/evidence/P2/`.
- `tools/sim_strategies.py` — implements **Skilled-A** and **Random-1000** exactly as below.
- `tests/` for the generator (kernels, pinning, seeding, rounding, determinism) and for each acceptance test (including negative tests that must fail on deliberately broken data).
- Update `audit/gates.json` with the Phase P2 gates (verbatim from `08`).
- Audit section for P2 in `audit/AUDIT_LOG.md`.

## 3. Implementation spec (follow `04` literally)
1. **Inputs** come only from `data/*.json` produced in P1 (targets, events, instruments). Personality parameters and regime multipliers are the tables in `04` §2.1–§2.2; put them in `data/params.json` and read them from there.
2. **Time grid:** ticks `n = 0..600`, `t = n/2` s. Opening price of a session = prior session closing price (rounded to ₹0.05); first-live opens from `data/instruments.json`.
3. **Equation:** `lnP(n) = lnP(0) + D·t/300 + Σ_e J_e·K_e(t) + C(t) + X̃(n)`. Implement kernels exactly as `04` §3 (jump, ramp40, pead, spike_fade, dip_revert, war/rate/crisis shock & stimulus, crash). `D` is solved so that the pre-rounding endpoint equals `ln(1+r/100)` (target). `X̃` is the pinned texture (`X(n) − (n/600)·X(600)`).
4. **Factors:** one `Z_mkt` per session; one `Z_sec` per sector group (ENRG, BANK, TECH, CONS, INFR; DIGI and SAFE separate); one `Z_idio` per ticker. Apply the stress uplifts to `a`, `b` from `04` §2 only after the shock event time.
5. **Seeding:** `seed(scope) = uint64(SHA256(master_seed|g|scope)[0:8])`, `numpy.random.Generator(PCG64(seed))`; scopes as listed in `04` §4. **Seed acceptance:** for each session independently, iterate `k = 0,1,2,…` (max 2000) with `master_seed + k` until all session-level tests pass; record `k`. Sessions are generated in order g1→g6 (a session's open depends on the previous close).
6. **Rounding & tick clamp:** round to ₹0.05; enforce ≤ 1.5% per tick; count and report every clip.
7. **Volume:** per `04` §6.
8. **Pre-history:** per `04` §9.
9. **Hashing:** SHA-256 over canonical byte serialisation of the arrays; store in `data/r1_arrays.sha256`; document the serialisation in the verify script.
10. **No tuning of parameters.** The only degree of freedom is `k`. If no `k ≤ 2000` passes a session, **stop**, record diagnostics (which test, best-achieved value) and write a `CHANGE_REQUESTS.md` entry. Do not alter targets, events, σ, κ, φ, a, b, cycle amplitude or thresholds.

## 4. Test definitions (implement exactly)
- **T1:** `|close/open − 1 − r/100|` ≤ 0.0005 (0.05%) for every (instrument, session).
- **T2:** run the full generation twice in separate processes; compare SHA-256.
- **T3:** `open(g+1) == close(g)` exactly in paise. **T4:** max `|ΔP/P|` per tick ≤ 1.5%.
- **T5:** correlation of 1-second-bar log returns, INFY-Z vs NIMBUS, per session R1S2–R1S6, each ≥ 0.45.
- **T6 (EDGE-A):** on TATA-Y and CRANE (when live) using 1-s bars: enter long when `P < SMA20×0.992`; exit when `P > SMA20×1.008` or after 30 bars; one position at a time; charge 0.10% per side. Report mean net return per trade, win rate, trades per session. Gates: mean ≥ +0.5%, win ≥ 60%, ≥ 3 trades/session for TATA-Y in every R1 session.
- **T7 (EDGE-B):** buy 2 s after `t_E` of E2.2 (INFY-Z) and E2.5 (NIMBUS), hold 40 s, net of fees ≥ +1.5% each.
- **T8 (EDGE-C):** for E1.2 and E3.3 on BZR-V: (peak price) → (price 30 s after the peak) drop ≥ 3%.
- **T9 (EDGE-G):** on bars where `|r| ≥ 1.5σ`: classify confirmed (volume ≥ 1.5× its 20-bar mean and aligned with 5-bar trend) vs unconfirmed. Confirmed: share where the next 20-bar return has the same sign ≥ 60%. Unconfirmed: share where it has the opposite sign ≥ 60%. Report n for each.
- **T10:** per instrument per session, std of tick log-returns (excluding event windows) within ±25% of `σ·m_g`.
- **T11:** GOLDCORE session range ≤ 1.5% (R1S4 ≤ 4%).
- **T12 (spread check):** for each event, from the kernel alone (without texture), the time to reach 50% and 90% of its largest excursion: 50% ≥ 3 s after `t_e`, 90% ≥ 6 s after.
- **T13 (solvability):**
  - *Skilled-A* (deterministic, no hindsight): capital ₹10 L per session start carried over; 25% GOLDCORE at session start; TATA-Y/CRANE by T6 rules; INFY-Z, NIMBUS, HDFC-W: hold while `SMA9 > SMA20`, exit on cross-down; on an NP or AN item with implied ▲ (or ▼), act only if the ticker's price already moved ≥ 0.3% in that direction in the last 10 s, within 5 s of release; **ignore FF**; sell BZR-V if up ≥ 2% in 10 s; max 60 trades/session; 0.10% fee per fill; long-only.
  - *Random-1000:* 1000 bots, fixed seed, 5 random trades per session (random live ticker, random side feasible, random size 10–50% of cash or holding).
  - **Gates:** Skilled-A net ≥ +1.5% in ≥ 5 of 6 sessions and ≥ +12% cumulative; Random-1000 median cumulative ≤ −0.5% and ≤ 5% of random bots beat Skilled-A.

## 5. Gates (all HARD; verbatim from `08`)
G2.1 T1 · G2.2 T2 · G2.3 T3/T4 · G2.4 T5 · G2.5 T6 · G2.6 T7+T8 · G2.7 T9+T10+T11 · G2.8 T12 · G2.9 T13 · G2.10 pre-history (240 ticks/instrument, endpoint error ≤ ₹0.05) · G2.11 hashes committed · G2.12 ★ smoke of P1 (re-run all P1 ★ gates on the current commit).

## 6. Procedure
1. Implement generator → run → verify → iterate seed search.
2. Run every gate; write evidence JSON + raw outputs into `audit/evidence/P2/` (same format as P1; add `n` and distribution fields where relevant, e.g. T6 trade counts, clip counts).
3. Run `python tools/audit_verify.py P2` — exit 0 required. Also re-run `python tools/audit_verify.py P1` for the regression.
4. Complete the Phase P2 audit section (template §0–§10), including the accepted `k` per session, the number of tick clips, the arrays' SHA-256, and the T6/T9 sample sizes.
5. Freeze: commit the arrays, tag `phase-P2-pass` only if all gates PASS.

## 7. Final output to the organizer
(a) Gate table with measured vs threshold; (b) the accepted `k` per session; (c) three PNG charts per R1 session saved in `audit/evidence/P2/charts/` (all live instruments normalised to 100) so the organizer can eyeball the story arc; (d) open questions / change requests; (e) 3 commands to independently re-run. **Stop. Do not start Phase 3** until the organizer signs the P2 audit block.
